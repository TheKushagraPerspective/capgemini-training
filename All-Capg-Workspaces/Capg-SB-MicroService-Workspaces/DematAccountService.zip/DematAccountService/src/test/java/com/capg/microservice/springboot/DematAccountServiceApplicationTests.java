package com.capg.microservice.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DematAccountServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
